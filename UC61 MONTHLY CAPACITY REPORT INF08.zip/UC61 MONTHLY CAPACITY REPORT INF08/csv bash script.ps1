﻿#!/bin/bash
#Fabien Denyset & Jean-Jacques Muller
#set -x
DATE=`date +"%y-%m-%d"`
MONTH=`date +"%m-%y"`
#BASE_FOLDER="/net/vfilrt03/vol/volmt03_01/home_di/filers-tools/SAN_TOOLS/REPORTING/brocade"
BASE_FOLDER="/root/Nitesh"
REPORT="SAN_KPI_SWITCH.csv"
REPORT_DIR="${BASE_FOLDER}/reports"
CONF_DIR="${BASE_FOLDER}/conf"
USER=adminabc
# Filename containing password
PASS=$1

echo "Date;NATCO;Silo;Switch Name;IP Address;Serial Number;FOS Version;Physical 
Ports Installed;Switch Type;Switch Domain;Used Ports;Unused Ports;Missing SFP; 
Not Licensed Ports;ISL Ports;NPIV Ports;Reserved Ports" > ${REPORT_DIR}/${DATE}_${REPORT}

for i in DE FR UK SP
do
#
# Director switch early DCX and DCX 8510.3 ICL port filtering using grep -v " ------   -- "
#
for IP in `cat ${CONF_DIR}/dir_$i.lst | grep -v ^#`
        do
        HOST=`nslookup ${IP} | awk -F= '$1 ~/name / {print $2}' | sed -e 's/^ //' -e 's/.$//' | grep -v ^res`
        TOT_PHYS=`sshpass -f $PASS ssh -o StrictHostKeyChecking=no $USER@$IP switchshow  | grep -v " ------ " | awk '$8 ~/FC/ {PHYS+=1} END{print PHYS}'`
        SERIAL=`sshpass -f $PASS ssh -o StrictHostKeyChecking=no $USER@$IP chassisshow | awk '$1 ~/Serial/ {SERIAL=$3} END{print SERIAL}'`
        RESULTS=`sshpass -f $PASS ssh -o StrictHostKeyChecking=no $USER@$IP switchshow | grep -v " ------ " | awk '$1 ~/switchType/ {TYPE=$2} ; 
                 $1 ~/switchDomain/ {SWITCHDOM=$2} ;
                 $7 ~/Online/ {ONLINE+=1} ;
                 $9 ~/Disable/ {DISABLE+=1} ;
                 $5 ~/--/ && $7 ~/No_Module/ && $9 !~/No/ {MODULE+=1} ;
                 $10 ~/POD/ {LIC+=1} ;
                 $9~/E-Port/ {ISL+=1} ; 
                 $11 ~/N/ && $12 ~/Port/ {NPIV+=1} END{printf("%.0d;",TYPE); 
                 print SWITCHDOM";"ONLINE";"DISABLE";"MODULE";"LIC";"ISL";"NPIV}'`
        VERSION=`sshpass -f $PASS ssh -o StrictHostKeyChecking=no $USER@$IP version | grep Fabric | awk '{print $3}'`
        RESERVED=`sshpass -f $PASS ssh -o StrictHostKeyChecking=no $USER@$IP portname | grep -i reserved | wc -l`
        SILO=`grep $HOST ${CONF_DIR}/silos.conf | awk '{print $1}'`
        echo "$MONTH;$i;$SILO;$HOST;$IP;$SERIAL;$VERSION;$TOT_PHYS;$RESULTS;$RESERVED" >> ${REPORT_DIR}/${DATE}_${REPORT}
        done

#Edge
for IP in `cat ${CONF_DIR}/edge_$i.lst | grep -v ^#`
        do
        HOST=`nslookup ${IP} | awk -F= '$1 ~/name / {print $2}' | sed -e 's/^ //' -e 's/.$//' | grep -v ^res`
        TOT_PHYS=`sshpass -f $PASS ssh -o StrictHostKeyChecking=no $USER@$IP switchshow -portcount| awk '{printf ("%.0d\n",$4)}'`
        SERIAL=`sshpass -f $PASS ssh -o StrictHostKeyChecking=no $USER@$IP chassisshow | awk '$1 ~/Serial/ {SERIAL=$3} END{print SERIAL}'`
        VERSION=`sshpass -f $PASS ssh -o StrictHostKeyChecking=no $USER@$IP version | grep Fabric | awk '{print $3}'`
        RESULTS=`sshpass -f $PASS ssh -o StrictHostKeyChecking=no $USER@$IP switchshow | awk '$1 ~/switchType/ {TYPE=$2} ; $1 ~/switchDomain/ {SWITCHDOM=$2} ;$6 ~/Online/ {ONLINE+=1} ;  $8 ~/Disable/ {DISABLE+=1} ; $4 ~/--/ && $6 ~/No_Module/ && $8 !~/No/ {MODULE+=1} ; $9 ~/POD/ || $12 ~/license/ || $13 ~/license/{LIC+=1} ; $8 ~/E-Port/ {ISL+=1} ; $10 ~/N/ && $11 ~/Port/ {NPIV+=1} END{printf ("%.0d;",TYPE);print SWITCHDOM";"ONLINE";"DISABLE";"MODULE";"LIC";"ISL";"NPIV}'`
        RESERVED=`sshpass -f $PASS ssh -o StrictHostKeyChecking=no $USER@$IP portname | grep -i reserved | wc -l`
        SILO=`grep $HOST ${CONF_DIR}/silos.conf | awk '{print $1}'`
        echo "$MONTH;$i;$SILO;$HOST;$IP;$SERIAL;$VERSION;$TOT_PHYS;$RESULTS;$RESERVED" >> ${REPORT_DIR}/${DATE}_${REPORT}
done




# Old Edge
# for IP in `cat ${CONF_DIR}/oldies_$i.lst | grep -v ^#`
# do
#       HOST=`nslookup ${IP} | awk -F= '$1 ~/name / {print $2}' | sed -e 's/^ //' -e 's/.$//' | grep -v ^res`
#       TOT_PHYS=`sshpass -p $PASS ssh -o StrictHostKeyChecking=no $USER@$IP switchshow -portcount| awk '{printf ("%.0d\n",$4)}'`
#       SERIAL=`sshpass -p $PASS ssh -o StrictHostKeyChecking=no $USER@$IP chassisshow | awk '$1 ~/Serial/ {SERIAL=$3} END{print SERIAL}'`
#       RESULTS=`sshpass -p $PASS ssh -o StrictHostKeyChecking=no $USER@$IP switchshow | awk '$1 ~/switchType/ {TYPE=$2} ; $1 ~/switchDomain/ {SWITCHDOM=$2}; $5 ~/Online/ {ONLINE+=1} ; $6 ~/Disable/ {DISABLE+=1} ; $3 ~/--/ && $5 ~/No_Module/ && $7 !~/No/ {MODULE+=1} ; $7 ~/POD/ {LIC+=1} ; $8 ~/E-Port/ {ISL+=1} ;$8 ~/N/ && $9 ~/Port/ {NPIV+=1} END{printf ("%.0d;",TYPE);print SWITCHDOM";"ONLINE";"DISABLE";"MODULE";"LIC";"ISL";"NPIV}'`
#       VERSION=`sshpass -p $PASS ssh -o StrictHostKeyChecking=no $USER@$IP version | grep Fabric | awk '{print $3}'`
#       RESERVED=`sshpass -p $PASS ssh -o StrictHostKeyChecking=no $USER@$IP portname | grep -i reserved | wc -l`
#        SILO=`grep $HOST ${CONF_DIR}/silos.conf | awk '{print $1}'`
#        echo "$MONTH;$i;$SILO;$HOST;$IP;$SERIAL;$VERSION;$TOT_PHYS;$RESULTS;$RESERVED" >> ${REPORT_DIR}/${DATE}_${REPORT}
#
done
cp ${REPORT_DIR}/${DATE}_${REPORT} ${REPORT_DIR}/${DATE}_${REPORT}.orig ${BASE_FOLDER}/postproc.sh ${REPORT_DIR}/${DATE}_${REPORT} 0
#mutt -e 'my_hdr From:dlfr.ahs-storage-airbus.ext@atos.net' -s "Brocade Report" 
$MAILTO -a ${REPORT_DIR}/${DATE}_${REPORT} < mail_tmpl/msg