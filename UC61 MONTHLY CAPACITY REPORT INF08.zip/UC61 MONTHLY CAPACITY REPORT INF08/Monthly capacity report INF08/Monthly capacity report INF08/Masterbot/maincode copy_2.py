import os,sys
import csv
from datetime import datetime
import getpass as getpass
import pandas as pd
from openpyxl import load_workbook
from openpyxl.utils import get_column_letter 
import os
import logging
import csv
from configparser import ConfigParser
import warnings
warnings.filterwarnings('ignore')

formatter = logging.Formatter('%(asctime)s : %(levelname)s : %(message)s')


# ---multi logger function to create multiple logs-------
def setup_logger(name, log_file="", level=logging.INFO):
    a = os.path.realpath(__file__)
    directory = os.path.dirname(os.path.dirname(a)) + "\\Logs\\" + name + ".log"
    """To setup as many loggers as you want"""
    handler = logging.FileHandler(directory)
    handler.setFormatter(formatter)
    logger = logging.getLogger(name)
    logger.setLevel(level)
    logger.addHandler(handler)
    return logger

filename = datetime.now()
logger = setup_logger(filename.strftime("%d-%b-%Y"))

def df_calculater(file_path):

    df = pd.read_csv(file_path)
    df = df.fillna(0)
    file_base_name = os.path.splitext(os.path.basename(file_path))[0]
    file_base_name = os.path.splitext(os.path.basename(brocade_model_path))[0]
    brocade_df= pd.read_csv(brocade_model_path)#create log


    #code to calculate switch capabilities and switch model
    x=len(df)
    for i in range(x):
        target_value=df['Switch Type'][i]
        indices = brocade_df[brocade_df == target_value].stack().index
        len_indices=len(indices)    
        if(len_indices==0):
            logger.error(f"Target Value '{target_value}' of switch type is not found in brocade sheet")
        else:
            for index in indices:
                row_index, col_index = index
                logger.info(f"Target Value '{target_value}' of switch type is found in brocade sheet at Row {row_index}, Column {col_index}")
                #print(f"Value '{target_value}' found at Row {row_index}, Column {col_index}")
                if(col_index == 'Unnamed: 0') :
                    df['Switch Capability'][i]=brocade_df.iloc[row_index][3]
                    df['Switch Model'][i]=brocade_df.iloc[row_index][1]
              
                

    #code to develop director/switch/Access Gateway
    for i in range(x):    
        val= df['Switch Model'][i]
        if (val== "DCX 8510-4" or val== "DCX 8510-8" or val == "DCX" or val== "SN8600B"):
            df['Director/switch'][i] = "Director"
        elif (val== "5480" or val == "4024"):
            df['Director/switch'][i] = "Access Gateway"
        else:
            df['Director/switch'][i] = "Switch"



    #code to develop 'Licensed Ports'
    for i in range(x):
        df['Licensed Ports'][i]=df['Ports Installed'][i]-df['Not Licensed Ports'][i]

    #code to develop 'Installed SFP'
    for i in range(x):
        df['Installed SFP'][i]=df['Licensed Ports'][i]-df['Missing SFP'][i]


    #code to develop 'Available Ports'
    for i in range(x):
        df['Available Ports'][i]=df['Unused Ports'][i]+df['Not Licensed Ports'][i]

    #code to develop '%Used Licensed Ports'
    df['%Used Licensed Ports']=(df['Used Ports']/df['Licensed Ports'])
    percentage_format = "{:.2%}"
    # Concatenate the percentage with each value in the Series
    df['%Used Licensed Ports'] = df['%Used Licensed Ports'].apply(lambda x: percentage_format.format(x))


    #code to develop '%Used Capability Ports'
    df['%Used Capability Ports']=(df['Used Ports']/df['Licensed Ports'])
    percentage_format = "{:.2%}"
    # Concatenate the percentage with each value in the Series
    df['%Used Capability Ports'] = df['%Used Capability Ports'].apply(lambda x: percentage_format.format(x))

    logger.info(f"final dataframe has been created successfully after calculation at {file_base_name}")
    return file_base_name,df


    
def excel_write(file_base_name, df):
    output_excel_path = os.path.join(OutputFile_path_name,f'{file_base_name}_final_output.xlsx' )
    df.to_excel(output_excel_path,index=False)

    with pd.ExcelWriter(output_excel_path, engine='openpyxl') as writer:
        df.to_excel(writer, sheet_name='Data', index=False)

        # Access the openpyxl workbook and worksheet objects
        workbook = writer.book
        worksheet = writer.sheets['Data']

        # Automatically adjust column widths based on content
        for column_index, column_name in enumerate(df.columns):
            max_length =0
            column_letter = get_column_letter(column_index + 1)  # Get the column name (e.g., 'A', 'B', 'C')
            
            for cell in worksheet[column_letter]:
                try:  # Avoid error if the cell has no value
                    if len(str(cell.value)) > max_length:
                        max_length = len(str(cell.value))
                except:
                    pass
            adjusted_width = (max_length + 2)  # Add extra space for readability
        
            worksheet.column_dimensions[column_letter].width = adjusted_width
    logger.info(f"Final excel file is created at location '{output_excel_path}'")

try:
    microbot_path_name = os.path.join(os.path.dirname(os.path.dirname(os.path.realpath(__file__))), "Microbots")
    OutputFile_path_name = os.path.join(os.path.dirname(os.path.dirname(os.path.realpath(__file__))), "OutputFiles")
    sys.path.append(microbot_path_name)



    #file_path='C:/Users/NITESRAI/OneDrive - Capgemini/ADC-2023/OneDrive - Capgemini/UC61 MONTHLY CAPACITY REPORT INF08/Monthly capacity report INF08/Monthly capacity report INF08/Input files/data1.csv'
    #brocade_model_path ='C:/Users/NITESRAI/OneDrive - Capgemini/ADC-2023/OneDrive - Capgemini/UC61 MONTHLY CAPACITY REPORT INF08/Monthly capacity report INF08/Monthly capacity report INF08/Input files/brocade_model_correct1.csv'  # Update with the correct path
    #brocade_df = pd.read_csv(brocade_model_path)


    path = __file__
    a = os.path.realpath(__file__)
    print(os.path.dirname(a))
    directory =os.path.dirname(os.path.dirname(a))
    file = directory + "\\Input files" + "\\config.ini"
    print(file)
    config = ConfigParser()
    config.read(file)
    file_path = config['requirements']['file_path'].strip()
    brocade_model_path = config['requirements']['brocade_model_path'].strip()
    

    if(os.path.exists(file_path)):
        logger.info(f"Input Csv is present at {file_path} ")
        with open(file_path, 'r', encoding='utf-8-sig') as csvfile:
            csv_reader = csv.DictReader(csvfile)
          
    else:
        logger.error(f"Input Csv is not present: {file_path}")
        exit()

    if(os.path.exists(brocade_model_path)):
        logger.info(f"brocade sheet is present at {brocade_model_path} ")
        base_file,final_df = df_calculater(file_path)
        excel_write(base_file,final_df)
    else:
        logger.error(f"brocade sheet is not present: {brocade_model_path}")
        exit()

    

except Exception as e:
    print(e)
    logger.error("Exception in Monthly capacity report INF08 ", str(e))