import os,sys
import time
import csv
import datetime
import getpass as getpass
import pandas as pd
from openpyxl import load_workbook
from openpyxl.utils import get_column_letter  # Import get_column_letter
#import paramiko
# coding=utf-8

current_date = datetime.datetime.now().date()
#print(current_date)
formatted_date = current_date.strftime("%Y_%b_%d") # Format the date as "YYYY_MM_DD"
#print("Today's Date:", formatted_date)
log_path = os.path.join(os.path.dirname(os.path.dirname(os.path.realpath(__file__))), "Logs")
log_file_path = os.path.join(log_path, formatted_date + "_logs", formatted_date + "_logs.log")
microbot_path_name = os.path.join(os.path.dirname(os.path.dirname(os.path.realpath(__file__))), "Microbots")
OutputFile_path_name = os.path.join(os.path.dirname(os.path.dirname(os.path.realpath(__file__))), "OutputFiles")
#print(microbot_path_name)
sys.path.append(microbot_path_name)

import LMB32_write_logs

#open and read the inventory
file_path='C:/Users/NITESRAI/Documents/UC 61/Monthly capacity report INF08/Input files/data1.csv'
brocade_model_path = 'C:/Users/NITESRAI/Documents/UC 61/Monthly capacity report INF08/Input files/brocade_model_correct1.csv'  # Update with the correct path
#brocade_df = pd.read_csv(brocade_model_path)

import csv
try:
  if os.path.exists(file_path):
    LMB32_write_logs.write_log("Input Csv is present ",formatted_date,log_path,"Info")
    with open(file_path, 'r', encoding='utf-8-sig') as csvfile:
        csv_reader = csv.DictReader(csvfile)
        for row in csv_reader:
            print(row)
            #LMB32_write_logs.write_log("Input Csv is present ",formatted_date,log_path,"Info")
  else:
    log_message = f"Input Csv is not present: {file_path}"
    LMB32_write_logs.write_log("log_message", formatted_date, log_path, "Info")
    # You can also log this information to a log file if needed.
    #print(csv_reader)
 #print(csv data)


#print("step2")
  df = pd.read_csv(file_path)
  df = df.fillna(0)
  file_base_name = os.path.splitext(os.path.basename(file_path))[0]
  
  file_base_name = os.path.splitext(os.path.basename(brocade_model_path))[0]
  brocade_df= pd.read_csv(brocade_model_path)


  #code to calculate switch capabilities and switch model
  x=len(df)
  for i in range(x):
      target_value=df['Switch Type'][i]
      print(target_value)
      #print(target_value)
      indices = brocade_df[brocade_df == target_value].stack().index    
      #print(indices)
      for index in indices:
          #print(index)
          row_index, col_index = index
          #print(f"Value '{target_value}' found at Row {row_index}, Column {col_index}")
          if(col_index == 'Unnamed: 0') :
              #print(col_index)
              print(i)
              df['Switch Capability'][i]=brocade_df.iloc[row_index][3]
              #print(df['Switch Capability'][i])
              #print(brocade_df.iloc[row_index][1])
              df['Switch Model'][i]=brocade_df.iloc[row_index][1]
              #print(df['Switch Model'][i])
            
  #LMB32_write_logs.write_log("Calculated the switch capabiliyty ",formatted_date,log_path,"Info")


  #code to develop director/switch/Access Gateway
  for i in range(x):    
      val= df['Switch Model'][i]
      if (val== "DCX 8510-4" or val== "DCX 8510-8" or val == "DCX" or val== "SN8600B"):
          df['Director/switch'][i] = "Director"
      elif (val== "5480" or val == "4024"):
          df['Director/switch'][i] = "Access Gateway"
      else:
          df['Director/switch'][i] = "Switch"
      #df['Director/switch'] = result
  #print(df['Director/switch'])



  #code to develop 'Licensed Ports'
  for i in range(x):
      df['Licensed Ports'][i]=df['Ports Installed'][i]-df['Not Licensed Ports'][i]
  #print(df['Licensed Ports'])

    #code to develop 'Installed SFP'
  for i in range(x):
      df['Installed SFP'][i]=df['Licensed Ports'][i]-df['Missing SFP'][i]
  #print(df['Installed SFP'])


  #code to develop 'Available Ports'
  for i in range(x):
      df['Available Ports'][i]=df['Unused Ports'][i]+df['Not Licensed Ports'][i]
  #print(df['Available Ports'])

    #code to develop '%Used Licensed Ports'
  df['%Used Licensed Ports']=(df['Used Ports']/df['Licensed Ports'])
  percentage_format = "{:.2%}"
  # Concatenate the percentage with each value in the Series
  df['%Used Licensed Ports'] = df['%Used Licensed Ports'].apply(lambda x: percentage_format.format(x))
  #print(df['%Used Licensed Ports'])


  #code to develop '%Used Capability Ports'
  df['%Used Capability Ports']=(df['Used Ports']/df['Licensed Ports'])
  percentage_format = "{:.2%}"
  # Concatenate the percentage with each value in the Series
  df['%Used Capability Ports'] = df['%Used Capability Ports'].apply(lambda x: percentage_format.format(x))
  #print(df['%Used Capability Ports'])

#final output
  print(df)
    

  output_excel_path = os.path.join(OutputFile_path_name,f'{file_base_name}_output.xlsx' )
  df.to_excel(output_excel_path,index=False)

  with pd.ExcelWriter(output_excel_path, engine='openpyxl') as writer:
        df.to_excel(writer, sheet_name='Data', index=False)

        # Access the openpyxl workbook and worksheet objects
        workbook = writer.book
        worksheet = writer.sheets['Data']

        # Automatically adjust column widths based on content
        for column_index, column_name in enumerate(df.columns):
            max_length =0
            column_letter = get_column_letter(column_index + 1)  # Get the column name (e.g., 'A', 'B', 'C')
            
            for cell in worksheet[column_letter]:
                try:  # Avoid error if the cell has no value
                    if len(str(cell.value)) > max_length:
                        max_length = len(str(cell.value))
                except:
                    pass
            adjusted_width = (max_length + 2)  # Add extra space for readability
            worksheet.column_dimensions[column_letter].width = adjusted_width

 
except Exception as e:
        print(e)
        LMB32_write_logs.write_log("Exception in Monthly capacity report INF08 ", str(e), formatted_date, log_path, "Error")