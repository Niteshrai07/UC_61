import os,sys
import time
import datetime
import getpass as getpass
import pandas as pd
from openpyxl import load_workbook
from openpyxl.utils import get_column_letter  # Import get_column_letter
#import paramiko
# coding=utf-8

current_date = datetime.datetime.now().date()
#print(current_date)
formatted_date = current_date.strftime("%Y_%b_%d") # Format the date as "YYYY_MM_DD"
print("Today's Date:", formatted_date)
log_path = os.path.join(os.path.dirname(os.path.dirname(os.path.realpath(__file__))), "Logs")
log_file_path = os.path.join(log_path, formatted_date + "_logs", formatted_date + "_logs.log")
microbot_path_name = os.path.join(os.path.dirname(os.path.dirname(os.path.realpath(__file__))), "Microbots")
OutputFile_path_name = os.path.join(os.path.dirname(os.path.dirname(os.path.realpath(__file__))), "OutputFiles")
print(microbot_path_name)
sys.path.append(microbot_path_name)

import LMB32_write_logs

#open and read the inventory
#file_path = 'C:/Airbus/Monthly capacity report INF08/Input files/reportDataPayload1.csv'
file_path='C:/Users/NITESRAI/Documents/UC 61/Monthly capacity report INF08/Input files/data.csv'
brocade_model_path = 'C:/Users/NITESRAI/Documents/UC 61/Monthly capacity report INF08/Input files/brocade_model_correct.csv'  # Update with the correct path
#brocade_df = pd.read_csv(brocade_model_path)
def buscarv(value, lookup_data):
    for index, row in lookup_data.iterrows():
        if row['Value'] == value:
            return row['Model']

import csv
try:
  if os.path.exists(file_path):
    LMB32_write_logs.write_log("Input Csv is present ",formatted_date,log_path,"Info")
    with open(file_path, 'r', encoding='utf-8-sig') as csvfile:
        csv_reader = csv.DictReader(csvfile)
        for row in csv_reader:
            print(row)
            #LMB32_write_logs.write_log("Input Csv is present ",formatted_date,log_path,"Info")
  else:
    log_message = f"Input Csv is not present: {file_path}"
    LMB32_write_logs.write_log("log_message", formatted_date, log_path, "Info")
    # You can also log this information to a log file if needed.
    #print(csv_reader)
 #print(csv data)


  print("step2")
  df = pd.read_csv(file_path)
  print(df.head(10))
  file_base_name = os.path.splitext(os.path.basename(file_path))[0]
  print("its "+file_base_name)


  file_base_name = os.path.splitext(os.path.basename(brocade_model_path))[0]
  print(file_base_name)

  brocade_df= pd.read_csv(brocade_model_path)
  print(brocade_df.head(10))
  

  print("Actions starts here")

  #calculating the 'Director/switch'
  #R13 = "DCX 8510-4"
  if (df['Switch Model'] == "DCX 8510-4" or df['Switch Model'] == "DCX 8510-8" or df['Switch Model'] == "DCX" or df['Switch Model'] == "SN8600B"):
    result = "Director"
  elif (df['Switch Model'] == "5480" or df['Switch Model'] == "4024"):
    result = "Access Gateway"
  else:
    result = "Switch"
  df['Director/switch'] = result

  df['Switch Model'] = '' # this cloumn need to add acc to the excel formula




  #calculating Switch capability
  lookup_value = df['Switch Type']
  df['Switch Capability']= brocade_df[brocade_df.iloc[brocade_df[Unnamed: 0][0]:D33,0] == lookup_value].iloc[0, 3]
  result = df[df.iloc[:, 0] == lookup_value].iloc[0, 3]




  df['Licensed Ports'] = df['Physical Ports Installed'] - df['Not Licensed Ports']
  df['Installed SFP'] = df['Licensed Ports'] - df['Missing SFP']
  df['Available Ports'] = df['Physical Ports Installed'] - df['Used Ports'] -df['Reserved Ports']
  df['%Used Licensed Ports'] = ( (df['Used Ports'] + df['Reserved Ports'] )/ df['Licensed Ports'] )* 100
  df['%Used Capability Ports'] =(df['Used Ports'] +df['Reserved Ports'])/ df['Switch Capability']# this  column will be calculated on the basis of the above column formula- {used port +reserved port /switch capability }
  #df['Director/switch'] = ''        # this cloumn need to add acc to the excel formula

#calculating Switch Model




 # Use the custom function 'buscarv' to lookup values in the 'Switch Type' column

  

  output_excel_path = os.path.join(OutputFile_path_name,f'{file_base_name}_output.xlsx' )
  df.to_excel(output_excel_path,index=False)

  with pd.ExcelWriter(output_excel_path, engine='openpyxl') as writer:
        df.to_excel(writer, sheet_name='Data', index=False)

        # Access the openpyxl workbook and worksheet objects
        workbook = writer.book
        worksheet = writer.sheets['Data']

        # Automatically adjust column widths based on content
        for column_index, column_name in enumerate(df.columns):
            max_length =0
            column_letter = get_column_letter(column_index + 1)  # Get the column name (e.g., 'A', 'B', 'C')
            
            for cell in worksheet[column_letter]:
                try:  # Avoid error if the cell has no value
                    if len(str(cell.value)) > max_length:
                        max_length = len(str(cell.value))
                except:
                    pass
            adjusted_width = (max_length + 2)  # Add extra space for readability
            worksheet.column_dimensions[column_letter].width = adjusted_width

 

except Exception as e:
        print(e)
        LMB32_write_logs.write_log("Exception in Monthly capacity report INF08 ", str(e), formatted_date, log_path, "Error")